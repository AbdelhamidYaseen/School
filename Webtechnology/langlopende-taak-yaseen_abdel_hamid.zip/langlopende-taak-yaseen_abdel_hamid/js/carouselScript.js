let flkty = new Flickity('.carousel');
$('.main-carousel').flickity({
    // options
    cellAlign: 'left',
    contain: true
  });