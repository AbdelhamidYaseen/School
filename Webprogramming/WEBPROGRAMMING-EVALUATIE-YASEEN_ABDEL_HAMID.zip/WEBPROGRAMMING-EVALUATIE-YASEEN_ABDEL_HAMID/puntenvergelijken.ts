export{}
const input = require("readline-sync");

let invoerMogelijkheden : string[]=["A","B","C","D","E","F"]
let invoerCountScores : string[] =["A","C","F","E","C","A"];

function countScores (scores : string[]){
    let aAmount : number = 0;
    let bAmount : number = 0;
    let cAmount : number = 0;
    let dAmount : number = 0;
    let eAmount : number = 0;
    let fAmount : number = 0;
    for(let i = 0; i<scores.length;i++){
        if(scores[i]=="A"){
            aAmount++;
        }
        else if(scores[i]=="B"){
            bAmount++;
        }
        else if(scores[i]=="C"){
            cAmount++;
        }
        else if(scores[i]=="D"){
            dAmount++;
        }
        else if(scores[i]=="E"){
            eAmount++;
        }
        else if(scores[i]=="F"){
            fAmount++;
        }
    }   
    console.log(`A: ${aAmount} B: ${bAmount} C: ${cAmount} D: ${dAmount} E: ${eAmount} F: ${fAmount}`)
}
console.log(countScores(invoerCountScores));

console.log("=====================================");

function correctScore(scores : string[],positie : number, correctScore : string){
    if(positie>scores.length){
        console.log("INVOER IS TE GROOT");
    }
    /*
    else if(scores.includes(invoerMogelijkheden[0]),scores.includes(invoerMogelijkheden[1]),scores.includes(invoerMogelijkheden[2]),scores.includes(invoerMogelijkheden[3]),scores.includes(invoerMogelijkheden[4]),scores.includes(invoerMogelijkheden[5])){
        console.log("ONGELDIGE LIJST!");
    }
    */
    else{
        scores[positie] = correctScore;
        console.log(scores);    
    }
}
console.log(correctScore( ["A", "I", "C"],4,"B"));
console.log("=====================================");
console.log(correctScore( ["A", "C", "F", "E", "C", "A"],2,"B"));





