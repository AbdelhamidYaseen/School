export{}
const input = require("readline-sync");

//===============================================================
function randomNumber(max: number): number 
{
    return Math.floor(Math.random() * (max + 1));   
}   
function assignRecipients(list : string[])
{
    for (let i = 0; i < list.length; i++) {
        let gifter : string = list[i];
        let receiver : string = list[i];
        let gettingGift : string[] = [];
        gettingGift.push(receiver);

        while(receiver == gifter || gettingGift.includes(receiver))
        {
            receiver = list[randomNumber(list.length-1)];
        }
        
        console.log(`${gifter} koopt een geheim cadeau voor ${receiver}`);
    }

}
//===============================================================
let persoon : string = " ";
let personenList : string[] = [];
//===============================================================
console.log("Wie doet er mee? Sluit af met een lege regel. ");
while (persoon != "")
{
    persoon = input.question("");
    personenList.push(persoon)
};
personenList.pop();
assignRecipients(personenList);
//===============================================================


















