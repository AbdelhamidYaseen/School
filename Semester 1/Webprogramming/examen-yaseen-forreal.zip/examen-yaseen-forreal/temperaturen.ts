export{}
const input = require("readline-sync");
const axios = require("axios");

export interface MainObject {
    stad:         string;
    temperaturen: Temperaturen[];
}

export interface Temperaturen {
    datum:       string;
    temperatuur: number;
}

function calculateAverage(numbers : number[]):number
{
    let totaal : number = 0;
    let gemiddelde : number = totaal/numbers.length;
    for (let i = 0; i < numbers.length; i++) {
        totaal = totaal + numbers[i];
    }

    return gemiddelde;
}

async function main()
{
    let response = await axios.get("https://ap-examen.surge.sh/temperaturen.json");
    let responseData : MainObject[] = response.data;
    for(let i: number = 0 ; i<responseData.length;i++){
        console.log(`${responseData[i].stad.toLocaleUpperCase()} ${"gemiddledeTemp"}°C`);
        for(let j : number = 0; j< responseData[i].temperaturen.length; j++)
        {
            console.log(`${responseData[i].temperaturen[j].datum}${" ".repeat(5)}${responseData[i].temperaturen[j].temperatuur}°C`);        
        }
    }
}
main();
















