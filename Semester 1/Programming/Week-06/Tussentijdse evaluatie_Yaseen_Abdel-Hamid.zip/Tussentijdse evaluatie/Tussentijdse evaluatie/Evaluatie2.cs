﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace Tussentijdse_evaluatie
{
    internal class Evaluatie2
    {
        public static void Piloot() {
            int vluchten;
            int maxUren;
            int duratie;
            int korteVlucht = 0;
            int langeVlucht = 0;
            int totaalDuratie = 0;
            Console.WriteLine("Hoeveel vluchten moet je doen?");
            vluchten = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Wat is het maximaal aantal minuten dat je mag vliegen op 1 vlucht?");
            maxUren = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= vluchten; i++)
            {
                Console.WriteLine($"Hoelang duurde vlucht {i}");
                duratie = Convert.ToInt32(Console.ReadLine());
                if (duratie < (maxUren / 100) * 70)
                {
                    korteVlucht++;
                    Console.WriteLine("Dit was een korte vlucht");
                }
                else 
                {
                    langeVlucht++;
                    Console.WriteLine("Dit was een lange vlucht");
                }
                totaalDuratie = totaalDuratie + duratie;
            }
            Console.WriteLine($"Er zijn {langeVlucht} lange vluchten en {korteVlucht} korte vluchten gedaan.");
            Console.WriteLine($"Er zijn in totaal {totaalDuratie} minuten gevlogen.");





        }

        public static void EWagen() {
            int keuze;
            int totaal = 0;
            int kWh = 0;
            bool trigger = true;
            while (trigger)
            {
                Console.WriteLine("Wat wil je doen?");
                Console.WriteLine("1. Elektriciteit toevoegen");
                Console.WriteLine("2. Elektriciteit afnemen");
                Console.WriteLine("3. Batterijniveau controleren en stoppen");
                Console.WriteLine("999. Stop the program");
                keuze = Convert.ToInt32(Console.ReadLine());
                if (keuze == 1)
                {
                    Console.WriteLine("Hoeveel kWh wil je toevoegen?");
                    kWh = Convert.ToInt32(Console.ReadLine());
                    totaal = totaal + kWh;
                    Console.WriteLine($"{kWh} kWh werd toegevoegd.");
                    Console.WriteLine("************************");
                }
                else if (keuze == 2)
                {
                    Console.WriteLine("Hoeveel kWh wil je afnemen?");
                    kWh = Convert.ToInt32(Console.ReadLine());
                    if (totaal > kWh)
                    {
                        Console.WriteLine("Oke dit krijg je");
                        totaal = totaal - kWh;
                        Console.WriteLine($"{kWh} kWh werd afgetrokken.");
                        Console.WriteLine("************************");
                    }
                    else if (totaal < kWh)
                    {
                        Console.WriteLine("Dit is niet mogelijk zoveel energie is er niet");
                        Console.WriteLine("************************");
                    }
                }
                else if (keuze == 3)
                {
                    Console.WriteLine($"Je batterijniveau bedraagt {totaal} kWh");
                    Console.WriteLine("************************");
                }
                else if (keuze == 999) {
                    Console.WriteLine("Stopping the program");
                    Console.WriteLine("************************");
                    trigger = false;
                }
                else { Console.WriteLine("Please select a correct input"); }


            }

        }


    }
}
