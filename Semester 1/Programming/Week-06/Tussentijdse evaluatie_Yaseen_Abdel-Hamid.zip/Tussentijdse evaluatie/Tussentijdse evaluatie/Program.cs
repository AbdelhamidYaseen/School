﻿using System;

namespace Tussentijdse_evaluatie
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string selected;
            Console.WriteLine("======================================================");
            Console.WriteLine("Please select an exercise");
            Console.WriteLine("======================================================");
            Console.WriteLine(
                "01| Oefening 1\n"+
                "02| Oefening 2"
                );
            Console.WriteLine("======================================================");
            selected = Console.ReadLine();
            Console.WriteLine("======================================================");
            if (selected == "01") { Evaluatie2.Piloot(); }
            else if (selected == "02") { Evaluatie2.EWagen(); }
            else { Console.WriteLine("Please select a correct input"); }
            Console.WriteLine("======================================================");

        }
    }
}
