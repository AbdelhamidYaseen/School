USE yaseenabdelhamid;
SELECT Soort FROM Vogels
	WHERE GewichtInGram > 50
    ORDER BY GewichtInGram ASC
;