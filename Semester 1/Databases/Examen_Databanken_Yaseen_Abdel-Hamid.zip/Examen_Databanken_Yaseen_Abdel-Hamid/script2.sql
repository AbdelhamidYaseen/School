USE yaseenabdelhamid;
SET SQL_SAFE_UPDATES = 0;
	DELETE FROM Vogels
	WHERE Vliegt = Zwemt;
    ;
SET SQL_SAFE_UPDATES = 1;
