﻿using System;

namespace LaboOefeningen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //VariabelenEnDatatypes.Optellen();
            //VariabelenEnDatatypes.VerbruikWagen();
            //VariabelenEnDatatypes.BeetjeWiskunde();
            //VariabelenEnDatatypes.Gemiddelde();
            //VariabelenEnDatatypes.Maaltafels();
            //VariabelenEnDatatypes.Ruimte();
        }
    }
}
