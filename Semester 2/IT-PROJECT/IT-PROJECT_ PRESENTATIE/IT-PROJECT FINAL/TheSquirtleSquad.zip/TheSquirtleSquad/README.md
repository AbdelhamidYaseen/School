# TheSquirtleSquad
Pokemon school project - Group project: [Bo Vranken][Ortwin Vanpottalsberghe][Robbe Dockx][Yaseen Abdel-Hamid]
