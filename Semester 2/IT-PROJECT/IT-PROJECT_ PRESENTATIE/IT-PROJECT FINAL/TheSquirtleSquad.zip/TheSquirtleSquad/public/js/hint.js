function myFunction() {
    var x = document.getElementById("hint");
    x.style.display = "block";
  }